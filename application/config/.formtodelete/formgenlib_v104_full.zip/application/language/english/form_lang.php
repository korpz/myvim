<?php

$lang['incorrect-captcha-sol']	= "The recaptcha solution was incorrect.";

/* End of file form_lang.php */
/* Location: ./application/language/english/form_lang.php */