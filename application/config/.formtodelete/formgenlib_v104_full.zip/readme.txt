INSTALLATION
Please see installation instructions at:
http://frankmichel.com/formgenlib/user_guide/installation/install.html

USER GUIDE
The user guide is not yet completed. You can find what's there at:
http://frankmichel.com/formgenlib/user_guide/

If you found bugs or have code improvements please contact me directly at:
info@frankmichel.com

I hope you enjoy using the library!